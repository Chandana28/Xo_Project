﻿using System;
using System.Threading.Tasks;
using XOProject.Controller;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using Moq;

namespace XOProject.Tests
{
    public class PortfolioControllerTests
    {
        private readonly Mock<ITradeRepository> _tradeRepositoryMock = new Mock<ITradeRepository>();
        private readonly Mock<IShareRepository> _shareRepositoryMock = new Mock<IShareRepository>();
        private readonly Mock<IPortfolioRepository> _portfolioRepositoryMock = new Mock<IPortfolioRepository>();

        private readonly PortfolioController _portfolioController;

        public PortfolioControllerTests()
        {
            _portfolioController = new PortfolioController(_shareRepositoryMock.Object, _tradeRepositoryMock.Object, _portfolioRepositoryMock.Object);
        }

        [Test]
        public async Task Get_ShouldGetPortfolio()
        {
            // Arrange
            var portfolioId = 11;

            // Act
            var result = await _portfolioController.GetPortfolioInfo(portfolioId);

            // Assert
            Assert.NotNull(result);
        }

        [Test]
        public async Task Post_ShouldAddNewPortfolioWithEmptyTrade()
        {
            // Arrange
            var portfolio = new Portfolio
            {
                Id = 50,
                Name = "Chandana",
                Trade = new System.Collections.Generic.List<Trade>()                
            };

            // Act
            var result = await _portfolioController.Post(portfolio);

            // Assert
            Assert.NotNull(result);

            var createdResult = result as CreatedResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(201, createdResult.StatusCode);
        }

        [Test]
        public async Task Post_ShouldAddNewPortfolioWithTrade()
        {
            // Arrange
            var trade1 = new Trade
            {
                Id = 500,
                Symbol = "REL",
                NoOfShares = 55,
                Price = 34,
                PortfolioId = 50,
                Action = "BUY"
            };
            var trade2 = new Trade
            {
                Id = 550,
                Symbol = "REL",
                NoOfShares = 67,
                Price = 23,
                PortfolioId = 50,
                Action = "SELL"
            };


            var portfolio = new Portfolio
            {
                Id = 50,
                Name = "Chandana",
                Trade = new System.Collections.Generic.List<Trade>() { trade1, trade2 }
            };

            // Act
            var result = await _portfolioController.Post(portfolio);

            // Assert
            Assert.NotNull(result);

            var createdResult = result as CreatedResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(201, createdResult.StatusCode);
        }
    }
}
