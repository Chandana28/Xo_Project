﻿using System;
using System.Threading.Tasks;
using XOProject.Controller;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using Moq;

namespace XOProject.Tests
{
    public class TradeControllerTests
    {
        private readonly Mock<ITradeRepository> _tradeRepositoryMock = new Mock<ITradeRepository>();
        private readonly Mock<IShareRepository> _shareRepositoryMock = new Mock<IShareRepository>();
        private readonly Mock<IPortfolioRepository> _portfolioRepositoryMock = new Mock<IPortfolioRepository>();

        private readonly TradeController _tradeController;

        public TradeControllerTests()
        {
            _tradeController = new TradeController(_shareRepositoryMock.Object, _tradeRepositoryMock.Object, _portfolioRepositoryMock.Object);
        }

        [Test]
        public async Task Get_ShouldGetTradingsAnalysis()
        {
            // Arrange
            var symbol = "REL";

            // Act
            var result = await _tradeController.GetAnalysis(symbol);

            // Assert
            Assert.NotNull(result);
        }

        [Test]
        public async Task Get_ShouldGetTradingsForPortfolio()
        {
            // Arrange
            var portfolioId = 1;

            // Act
            var result = await _tradeController.GetAllTradings(portfolioId);

            // Assert
            Assert.NotNull(result);
        }
    }
}
